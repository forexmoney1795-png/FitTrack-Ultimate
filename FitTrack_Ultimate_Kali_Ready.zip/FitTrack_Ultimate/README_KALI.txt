FITTRACK ULTIMATE — KALI LINUX APK

1) Extract this ZIP.
2) Open Terminal in the extracted FitTrack_Ultimate folder.
3) Run ONLY this command:

   ./build_apk.sh

The script installs/uses Java, finds your Android SDK, installs Android 35/build tools when sdkmanager is available, downloads Gradle 8.7, and builds the APK.

When finished, the APK is:

   FitTrack-Ultimate.apk

If it says Android SDK was not found:
- Open Android Studio.
- SDK Manager -> install Android SDK Platform 35 and Android SDK Build-Tools.
- Run the script again.

No Windows is required.
